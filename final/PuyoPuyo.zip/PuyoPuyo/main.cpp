
#include "controller/controller.h"

int main() {
    controller ct;
    ct.start();
    return 0;
}